export const theme = {
  colors: {
    primary: '#3B82F6', // Blue
    secondary: '#10B981', // Green
    accent: '#8B5CF6', // Purple
    background: '#F3F4F6', // Light gray
    text: '#1F2937', // Dark gray
    white: '#FFFFFF',
  },
}

