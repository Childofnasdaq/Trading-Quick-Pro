'use client'

import { Bar } from 'react-chartjs-2'
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js'

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
)

const options = {
  responsive: true,
  plugins: {
    legend: {
      display: false,
    },
  },
  scales: {
    y: {
      beginAtZero: true,
    },
  },
}

export function SalesChart() {
  const data = {
    labels: ['16/08', '17/08', '18/08', '19/08', '20/08', '21/08', '22/08', '23/08'],
    datasets: [
      {
        data: [100, 80, 0, 0, 0, 0, 0, 0],
        backgroundColor: 'rgb(99, 102, 241)',
        borderRadius: 4,
      },
    ],
  }

  return (
    <div className="bg-white p-6 rounded-lg shadow">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-lg font-semibold">Sales Overview</h2>
        <select className="border rounded-md px-2 py-1 text-sm">
          <option>March 2023</option>
        </select>
      </div>
      <Bar options={options} data={data} height={300} />
    </div>
  )
}

