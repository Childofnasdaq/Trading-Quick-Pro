import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'

const products = [
  {
    id: 1,
    name: 'Elite Admin',
    assigned: {
      name: 'Sunil Joshi',
      role: 'Web Designer',
    },
    priority: 'Low',
    budget: '$3.9k',
  },
  {
    id: 2,
    name: 'Real Homes WP Theme',
    assigned: {
      name: 'Andrew McDownland',
      role: 'Project Manager',
    },
    priority: 'Medium',
    budget: '$24.5k',
  },
  {
    id: 3,
    name: 'MedicalPro WP Theme',
    assigned: {
      name: 'Christopher Jamil',
      role: 'Project Manager',
    },
    priority: 'High',
    budget: '$12.8k',
  },
]

const priorityColors = {
  Low: 'bg-blue-100 text-blue-800',
  Medium: 'bg-yellow-100 text-yellow-800',
  High: 'bg-red-100 text-red-800',
}

export function ProductPerformance() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Product Performance</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="text-left">
                <th className="pb-4 text-sm font-medium text-gray-500">Id</th>
                <th className="pb-4 text-sm font-medium text-gray-500">Assigned</th>
                <th className="pb-4 text-sm font-medium text-gray-500">Name</th>
                <th className="pb-4 text-sm font-medium text-gray-500">Priority</th>
                <th className="pb-4 text-sm font-medium text-gray-500">Budget</th>
              </tr>
            </thead>
            <tbody>
              {products.map((product) => (
                <tr key={product.id} className="border-t">
                  <td className="py-4">{product.id}</td>
                  <td className="py-4">
                    <div>
                      <div className="font-medium">{product.assigned.name}</div>
                      <div className="text-sm text-gray-500">{product.assigned.role}</div>
                    </div>
                  </td>
                  <td className="py-4">{product.name}</td>
                  <td className="py-4">
                    <Badge className={priorityColors[product.priority as keyof typeof priorityColors]}>
                      {product.priority}
                    </Badge>
                  </td>
                  <td className="py-4">{product.budget}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  )
}

