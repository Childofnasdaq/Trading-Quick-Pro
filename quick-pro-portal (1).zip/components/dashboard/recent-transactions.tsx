import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

const transactions = [
  {
    time: '09:30 am',
    description: 'Payment received from John Doe',
    amount: '$385.90',
    type: 'payment',
  },
  {
    time: '10:00 am',
    description: 'New sale recorded',
    reference: '#ML-3467',
    type: 'sale',
  },
  {
    time: '12:00 am',
    description: 'Payment was made of $64.95 to Michael',
    type: 'payment',
  },
]

export function RecentTransactions() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Recent Transactions</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {transactions.map((transaction, index) => (
            <div key={index} className="flex items-start space-x-4">
              <div className="min-w-[80px] text-sm text-gray-500">
                {transaction.time}
              </div>
              <div>
                <p className="text-sm">{transaction.description}</p>
                {transaction.reference && (
                  <p className="text-sm text-blue-500">{transaction.reference}</p>
                )}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}

