'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { LayoutGrid, ShoppingCart, Key, BotIcon as Robot, BarChart, HelpCircle, LogOut } from 'lucide-react'

const menuItems = [
  { icon: LayoutGrid, label: 'Dashboard', href: '/dashboard' },
  { icon: ShoppingCart, label: 'Purchase keys', href: '/dashboard/purchase' },
  { icon: Key, label: 'Manage keys', href: '/dashboard/keys' },
  { icon: Robot, label: 'Manage EAs', href: '/dashboard/eas' },
  { icon: BarChart, label: 'Stats', href: '/dashboard/stats' },
  { icon: HelpCircle, label: 'Help', href: '/dashboard/help' },
]

export function Sidebar() {
  const pathname = usePathname()

  const handleLogout = () => {
    // Add logout logic here
  }

  return (
    <div className="w-64 h-screen bg-white border-r flex flex-col">
      <div className="p-4 border-b">
        <h1 className="text-xl font-bold">Quick Pro</h1>
      </div>
      <nav className="flex-1 p-4">
        <ul className="space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon
            return (
              <li key={item.href}>
                <Link
                  href={item.href}
                  className={`flex items-center space-x-3 px-3 py-2 rounded-lg transition-colors ${
                    pathname === item.href
                      ? 'bg-gray-100 text-gray-900'
                      : 'text-gray-600 hover:bg-gray-50'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span>{item.label}</span>
                </Link>
              </li>
            )
          })}
        </ul>
      </nav>
      <button
        onClick={handleLogout}
        className="flex items-center space-x-3 px-7 py-4 text-gray-600 hover:bg-gray-50 transition-colors border-t w-full"
      >
        <LogOut className="w-5 h-5" />
        <span>Logout</span>
      </button>
    </div>
  )
}

