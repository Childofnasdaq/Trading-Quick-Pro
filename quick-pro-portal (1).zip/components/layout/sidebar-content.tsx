'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { LayoutGrid, ShoppingCart, Key, Bot, BarChart2, HelpCircle, LogOut, ChevronRight, User } from 'lucide-react'
import { cn } from '@/lib/utils'

const menuItems = [
  { 
    title: 'HOME',
    items: [
      { icon: LayoutGrid, label: 'Dashboard', href: '/dashboard' },
    ]
  },
  {
    title: 'UTILITIES',
    items: [
      { icon: ShoppingCart, label: 'Purchase keys', href: '/dashboard/purchase' },
      { icon: Key, label: 'Manage keys', href: '/dashboard/keys' },
      { icon: Bot, label: 'Manage EAs', href: '/dashboard/eas' },
      { icon: BarChart2, label: 'Stats', href: '/dashboard/stats' },
      { icon: HelpCircle, label: 'Help', href: '/dashboard/help' },
    ]
  },
  {
    title: 'ACCOUNT',
    items: [
      { icon: User, label: 'Profile', href: '/dashboard/profile' },
    ]
  }
]

interface SidebarContentProps {
  className?: string
}

export function SidebarContent({ className }: SidebarContentProps) {
  const pathname = usePathname()

  return (
    <div className={cn("flex flex-col h-full", className)}>
      <div className="flex-1 py-4">
        {menuItems.map((section) => (
          <div key={section.title} className="mb-6">
            <div className="px-4 mb-2">
              <h3 className="text-xs font-medium text-gray-500">{section.title}</h3>
            </div>
            {section.items.map((item) => {
              const isActive = pathname === item.href
              const Icon = item.icon
              
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={cn(
                    "flex items-center h-10 px-4 gap-3 text-sm font-medium transition-colors rounded-md",
                    "hover:bg-gray-100",
                    isActive && "bg-blue-50 text-blue-600"
                  )}
                >
                  <Icon className="w-5 h-5" />
                  {item.label}
                  {isActive && <ChevronRight className="ml-auto w-4 h-4" />}
                </Link>
              )
            })}
          </div>
        ))}
      </div>

      <div className="border-t p-4">
        <button
          onClick={() => {/* Add logout logic */}}
          className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded-md"
        >
          <LogOut className="w-5 h-5 mr-3" />
          Logout
        </button>
      </div>
    </div>
  )
}

