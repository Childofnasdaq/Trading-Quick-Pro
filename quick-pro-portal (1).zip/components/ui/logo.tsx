export function Logo({ className = "", size = 40 }) {
  return (
    <img
      src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images%20(14)-taCFLZyOyMibQscTy9naD28d0ntjmW.jpeg"
      alt="QUICK PRO Bull Logo"
      className={className}
      width={size}
      height={size}
    />
  )
}

