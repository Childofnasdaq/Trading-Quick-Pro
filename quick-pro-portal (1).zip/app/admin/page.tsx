'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { theme } from '@/styles/theme'
import { toast } from '@/components/ui/use-toast'

export default function AdminPage() {
  const [pendingUsers, setPendingUsers] = useState<any[]>([])

  useEffect(() => {
    const users = JSON.parse(localStorage.getItem('users') || '[]')
    setPendingUsers(users.filter((user: any) => !user.isApproved))
  }, [])

  const approveUser = (username: string) => {
    const users = JSON.parse(localStorage.getItem('users') || '[]')
    const updatedUsers = users.map((user: any) => 
      user.username === username ? { ...user, isApproved: true } : user
    )
    localStorage.setItem('users', JSON.stringify(updatedUsers))
    setPendingUsers(pendingUsers.filter(user => user.username !== username))
    toast({
      title: "User Approved",
      description: `${username} has been approved.`,
    })
  }

  return (
    <div className="p-4 md:p-6">
      <Card className="max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle style={{ color: theme.colors.text }}>Admin Dashboard</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <h2 className="text-lg font-semibold" style={{ color: theme.colors.text }}>Pending Approvals</h2>
          {pendingUsers.length > 0 ? (
            pendingUsers.map((user, index) => (
              <div key={index} className="flex justify-between items-center">
                <span style={{ color: theme.colors.text }}>{user.username}</span>
                <Button onClick={() => approveUser(user.username)}>Approve</Button>
              </div>
            ))
          ) : (
            <p style={{ color: theme.colors.text }}>No pending approvals.</p>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

