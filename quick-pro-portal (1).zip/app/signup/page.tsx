"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Logo } from "@/components/ui/logo"
import { theme } from "@/styles/theme"
import { toast } from "@/components/ui/use-toast"

export default function SignupPage() {
  const router = useRouter()
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [isLoading, setIsLoading] = useState(false)

  const handleSignup = (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    const users = JSON.parse(localStorage.getItem("users") || "[]")

    if (users.some((u: any) => u.username === username)) {
      toast({
        title: "Signup Failed",
        description: "Username already exists. Please choose a different username.",
        variant: "destructive",
      })
      setIsLoading(false)
      return
    }

    const mentorId = generateMentorId()
    const referralCode = generateReferralCode()
    const newUser = { username, password, mentorId, referralCode, isApproved: false }
    users.push(newUser)
    localStorage.setItem("users", JSON.stringify(users))
    localStorage.setItem("currentUser", username)

    const userProfile = {
      username,
      email: "",
      icon: "",
      mentorId,
      referralCode,
    }
    localStorage.setItem("userProfile", JSON.stringify(userProfile))

    setIsLoading(false)
    router.push("/dashboard")
  }

  function generateMentorId() {
    return "M-" + Math.random().toString(36).substr(2, 8).toUpperCase()
  }

  function generateReferralCode() {
    return "REF-" + Math.random().toString(36).substr(2, 6).toUpperCase()
  }

  return (
    <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: theme.colors.background }}>
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <Logo size={60} />
          </div>
          <CardTitle style={{ color: theme.colors.text }}>QUICK PRO</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSignup} className="space-y-4">
            <div>
              <label htmlFor="username" className="block text-sm font-medium" style={{ color: theme.colors.text }}>
                Username
              </label>
              <Input
                id="username"
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                required
              />
            </div>
            <div>
              <label htmlFor="password" className="block text-sm font-medium" style={{ color: theme.colors.text }}>
                Password
              </label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
            <Button
              type="submit"
              className="w-full"
              disabled={isLoading}
              style={{ backgroundColor: theme.colors.primary, color: theme.colors.white }}
            >
              {isLoading ? "Creating account..." : "Sign Up"}
            </Button>
          </form>
          <p className="mt-4 text-center" style={{ color: theme.colors.text }}>
            Already have an account?{" "}
            <Link href="/login" className="text-blue-500 hover:underline">
              Login
            </Link>
          </p>
        </CardContent>
      </Card>
    </div>
  )
}

