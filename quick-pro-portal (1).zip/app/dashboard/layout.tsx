"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Sidebar } from "@/components/layout/sidebar"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { RefreshCw, Menu } from "lucide-react"
import { theme } from "@/styles/theme"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const router = useRouter()
  const [username, setUsername] = useState("")
  const [mentorId, setMentorId] = useState("")
  const [profile, setProfile] = useState<any>(null)

  useEffect(() => {
    const currentUser = localStorage.getItem("currentUser")
    if (!currentUser) {
      router.push("/login")
    } else {
      setUsername(currentUser)
    }

    const savedProfile = localStorage.getItem("userProfile")
    if (savedProfile) {
      const profileData = JSON.parse(savedProfile)
      setProfile(profileData)
      setMentorId(profileData.mentorId)
    }
  }, [router])

  const handleLogout = () => {
    localStorage.removeItem("currentUser")
    router.push("/login")
  }

  return (
    <div className="flex min-h-screen" style={{ backgroundColor: theme.colors.background }}>
      <div className="hidden md:flex">
        <Sidebar onLogout={handleLogout} />
      </div>
      <div className="flex-1">
        <div
          className="h-16 border-b px-4 md:px-6 flex items-center justify-between"
          style={{ backgroundColor: theme.colors.white }}
        >
          <div className="flex items-center gap-4">
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="md:hidden">
                  <Menu className="h-6 w-6" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="p-0">
                <Sidebar onLogout={handleLogout} />
              </SheetContent>
            </Sheet>
            <h1 className="text-xl font-semibold" style={{ color: theme.colors.text }}>
              Welcome to QUICK PRO, {username}
            </h1>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex flex-col items-center">
              <Avatar>
                <AvatarImage src={profile?.icon} alt={username} />
                <AvatarFallback>{username.charAt(0).toUpperCase()}</AvatarFallback>
              </Avatar>
              <span className="text-xs mt-1" style={{ color: theme.colors.text }}>
                {mentorId}
              </span>
            </div>
          </div>
        </div>
        <main className="p-4 md:p-6">{children}</main>
      </div>
    </div>
  )
}

