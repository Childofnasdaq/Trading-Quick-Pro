'use client'

import { useState } from 'react'
import { Copy, Plus, Search, Trash2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'

interface MetaApi {
  id: string
  username: string
  email: string
  licenseKey: string
  status: 'active' | 'inactive'
  createdAt: string
}

export default function EAsPage() {
  const [metaApis, setMetaApis] = useState<MetaApi[]>([
    {
      id: '1',
      username: 'trader1',
      email: 'trader1@example.com',
      licenseKey: 'D-1-75P9EGHI-M3N',
      status: 'active',
      createdAt: new Date().toISOString(),
    },
  ])

  const [searchQuery, setSearchQuery] = useState('')

  const handleCopyLicenseKey = (licenseKey: string) => {
    navigator.clipboard.writeText(licenseKey)
  }

  const handleCreateMetaApi = (data: Partial<MetaApi>) => {
    const newMetaApi: MetaApi = {
      id: Math.random().toString(36).substr(2, 9),
      username: data.username || '',
      email: data.email || '',
      licenseKey: generateLicenseKey(),
      status: 'active',
      createdAt: new Date().toISOString(),
    }
    setMetaApis([...metaApis, newMetaApi])
  }

  const generateLicenseKey = () => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
    let result = 'D-1-'
    for (let i = 0; i < 8; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length))
    }
    return result
  }

  const filteredMetaApis = metaApis.filter(
    (api) =>
      api.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
      api.email.toLowerCase().includes(searchQuery.toLowerCase())
  )

  return (
    <div className="container mx-auto p-6">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>MetaAPI Management</CardTitle>
          <Dialog>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Add New MetaAPI
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create New MetaAPI</DialogTitle>
              </DialogHeader>
              <form
                onSubmit={(e) => {
                  e.preventDefault()
                  const formData = new FormData(e.currentTarget)
                  handleCreateMetaApi({
                    username: formData.get('username') as string,
                    email: formData.get('email') as string,
                  })
                }}
                className="space-y-4"
              >
                <div className="space-y-2">
                  <label className="text-sm font-medium">Username</label>
                  <Input name="username" required />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Email</label>
                  <Input name="email" type="email" required />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Duration</label>
                  <Select name="duration" defaultValue="1">
                    <SelectTrigger>
                      <SelectValue placeholder="Select duration" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1">1 Month</SelectItem>
                      <SelectItem value="3">3 Months</SelectItem>
                      <SelectItem value="6">6 Months</SelectItem>
                      <SelectItem value="12">1 Year</SelectItem>
                      <SelectItem value="lifetime">Lifetime</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Button type="submit" className="w-full">Create</Button>
              </form>
            </DialogContent>
          </Dialog>
        </CardHeader>
        <CardContent>
          <div className="mb-4">
            <div className="relative">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-500" />
              <Input
                placeholder="Search MetaAPIs..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-8"
              />
            </div>
          </div>
          <div className="space-y-4">
            {filteredMetaApis.map((api) => (
              <Card key={api.id}>
                <CardContent className="flex items-center justify-between p-4">
                  <div className="space-y-1">
                    <p className="font-medium">{api.username}</p>
                    <p className="text-sm text-gray-500">{api.email}</p>
                    <div className="flex items-center gap-2">
                      <code className="text-sm bg-gray-100 px-2 py-1 rounded">
                        {api.licenseKey.slice(0, 8)}...
                      </code>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleCopyLicenseKey(api.licenseKey)}
                      >
                        <Copy className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      variant={api.status === 'active' ? 'default' : 'outline'}
                      onClick={() => {
                        setMetaApis(
                          metaApis.map((item) =>
                            item.id === api.id
                              ? { ...item, status: item.status === 'active' ? 'inactive' : 'active' }
                              : item
                          )
                        )
                      }}
                    >
                      {api.status === 'active' ? 'Active' : 'Inactive'}
                    </Button>
                    <Button
                      variant="destructive"
                      size="icon"
                      onClick={() => {
                        if (confirm('Are you sure you want to delete this MetaAPI?')) {
                          setMetaApis(metaApis.filter((item) => item.id !== api.id))
                        }
                      }}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

