'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { theme } from '@/styles/theme'

export default function ProfilePage() {
  const router = useRouter()
  const [profile, setProfile] = useState({
    username: '',
    email: '',
    password: '',
    icon: '',
    mentorId: '',
    referralCode: ''
  })
  const [isLoading, setIsLoading] = useState(false)

  useEffect(() => {
    const savedProfile = localStorage.getItem('userProfile')
    if (savedProfile) {
      setProfile(JSON.parse(savedProfile))
    } else {
      const currentUser = localStorage.getItem('currentUser')
      if (currentUser) {
        setProfile(prev => ({ ...prev, username: currentUser }))
      }
    }
  }, [])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setProfile(prev => ({ ...prev, [name]: value }))
  }

  const handleIconChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        setProfile(prev => ({ ...prev, icon: reader.result as string }))
      }
      reader.readAsDataURL(file)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    localStorage.setItem('userProfile', JSON.stringify(profile))
    await new Promise(resolve => setTimeout(resolve, 1000))
    setIsLoading(false)
    router.push('/dashboard')
  }

  return (
    <div className="p-4 md:p-6">
      <Card className="max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle style={{ color: theme.colors.text }}>Profile Settings</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="flex items-center space-x-4">
              <Avatar className="w-20 h-20">
                <AvatarImage src={profile.icon} alt="Profile" />
                <AvatarFallback>{profile.username?.charAt(0) || 'U'}</AvatarFallback>
              </Avatar>
              <Input
                type="file"
                accept="image/*"
                onChange={handleIconChange}
                className="w-auto"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium" style={{ color: theme.colors.text }}>
                Username
              </label>
              <Input
                name="username"
                value={profile.username}
                onChange={handleChange}
                required
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium" style={{ color: theme.colors.text }}>
                Email
              </label>
              <Input
                name="email"
                type="email"
                value={profile.email}
                onChange={handleChange}
                required
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium" style={{ color: theme.colors.text }}>
                New Password (leave blank to keep current)
              </label>
              <Input
                name="password"
                type="password"
                value={profile.password}
                onChange={handleChange}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium" style={{ color: theme.colors.text }}>
                Mentor ID
              </label>
              <Input
                name="mentorId"
                value={profile.mentorId}
                readOnly
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium" style={{ color: theme.colors.text }}>
                Referral Code
              </label>
              <Input
                name="referralCode"
                value={profile.referralCode}
                readOnly
              />
            </div>
            <Button type="submit" className="w-full" disabled={isLoading} style={{ backgroundColor: theme.colors.primary, color: theme.colors.white }}>
              {isLoading ? 'Saving...' : 'Save Profile'}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}

