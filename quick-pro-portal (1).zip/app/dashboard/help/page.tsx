'use client'

import { useState } from 'react'
import { Send, MessageSquare, ExternalLink } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { theme } from '@/styles/theme'
import { useChat } from 'ai/react'

interface Message {
  role: 'user' | 'assistant'
  content: string
}

export default function HelpPage() {
  const { messages, input, handleInputChange, handleSubmit } = useChat({
    api: '/api/chat',
  })

  const contactLinks = [
    {
      title: 'WhatsApp Support',
      description: 'Get instant help via WhatsApp',
      href: 'https://wa.me/27845566847',
    },
    {
      title: 'Email Support',
      description: 'Send us an email',
      href: 'mailto:help@childofnasdaqservices.co.za',
    },
  ]

  return (
    <div className="container mx-auto p-6">
      <Tabs defaultValue="chat">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="chat">AI Assistant</TabsTrigger>
          <TabsTrigger value="contact">Contact Support</TabsTrigger>
        </TabsList>
        
        <TabsContent value="chat">
          <Card>
            <CardHeader>
              <CardTitle style={{ color: theme.colors.text }}>Chat with AI Assistant</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[400px] space-y-4 overflow-y-auto mb-4">
                {messages.map((message, index) => (
                  <div
                    key={index}
                    className={`flex ${
                      message.role === 'user' ? 'justify-end' : 'justify-start'
                    }`}
                  >
                    <div
                      className={`max-w-[80%] rounded-lg px-4 py-2 ${
                        message.role === 'user'
                          ? 'bg-blue-500 text-white'
                          : 'bg-gray-100'
                      }`}
                      style={{
                        backgroundColor: message.role === 'user' ? theme.colors.primary : theme.colors.background,
                        color: message.role === 'user' ? theme.colors.white : theme.colors.text,
                      }}
                    >
                      {message.content}
                    </div>
                  </div>
                ))}
              </div>
              <form onSubmit={handleSubmit} className="flex gap-2">
                <Input
                  value={input}
                  onChange={handleInputChange}
                  placeholder="Ask about QUICK PRO..."
                  className="flex-1"
                />
                <Button type="submit" style={{ backgroundColor: theme.colors.primary, color: theme.colors.white }}>
                  <Send className="h-4 w-4" />
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="contact">
          <div className="grid gap-4">
            {contactLinks.map((link) => (
              <Card key={link.title}>
                <CardContent className="flex items-center justify-between p-6">
                  <div>
                    <h3 className="font-medium" style={{ color: theme.colors.text }}>{link.title}</h3>
                    <p className="text-sm" style={{ color: theme.colors.text }}>{link.description}</p>
                  </div>
                  <Button asChild style={{ backgroundColor: theme.colors.primary, color: theme.colors.white }}>
                    <a href={link.href} target="_blank" rel="noopener noreferrer">
                      Contact
                      <ExternalLink className="ml-2 h-4 w-4" />
                    </a>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

