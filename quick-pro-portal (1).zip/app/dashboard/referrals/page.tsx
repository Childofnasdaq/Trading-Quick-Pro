"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { theme } from "@/styles/theme"
import { toast } from "@/components/ui/use-toast"

export default function ReferralsPage() {
  const [profile, setProfile] = useState<any>(null)
  const [referrals, setReferrals] = useState<string[]>([])
  const [referralLink, setReferralLink] = useState("")

  useEffect(() => {
    const savedProfile = localStorage.getItem("userProfile")
    if (savedProfile) {
      const profileData = JSON.parse(savedProfile)
      setProfile(profileData)
      // Create referral link with the current domain
      const baseUrl = window.location.origin
      setReferralLink(`${baseUrl}/signup?ref=${profileData.referralCode}`)
    }

    const savedReferrals = localStorage.getItem("userReferrals")
    if (savedReferrals) {
      setReferrals(JSON.parse(savedReferrals))
    }
  }, [])

  const copyReferralLink = () => {
    navigator.clipboard.writeText(referralLink)
    toast({
      title: "Link Copied",
      description: "Referral link has been copied to clipboard.",
    })
  }

  return (
    <div className="p-4 md:p-6">
      <Card className="max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle style={{ color: theme.colors.text }}>Referral Program</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p style={{ color: theme.colors.text }}>
            Refer 5 people and get a free license key! Share your referral link with friends.
          </p>
          <div className="space-y-2">
            <label className="text-sm font-medium" style={{ color: theme.colors.text }}>
              Your Referral Link
            </label>
            <div className="flex items-center space-x-2">
              <Input value={referralLink} readOnly />
              <Button onClick={copyReferralLink}>Copy Link</Button>
            </div>
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium" style={{ color: theme.colors.text }}>
              Your Referral Code
            </label>
            <div className="flex items-center space-x-2">
              <Input value={profile?.referralCode || ""} readOnly />
              <Button
                onClick={() => {
                  navigator.clipboard.writeText(profile?.referralCode || "")
                  toast({
                    title: "Code Copied",
                    description: "Referral code has been copied to clipboard.",
                  })
                }}
              >
                Copy Code
              </Button>
            </div>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-2" style={{ color: theme.colors.text }}>
              Your Referrals
            </h3>
            {referrals.length > 0 ? (
              <ul className="list-disc list-inside">
                {referrals.map((referral, index) => (
                  <li key={index} style={{ color: theme.colors.text }}>
                    {referral}
                  </li>
                ))}
              </ul>
            ) : (
              <p style={{ color: theme.colors.text }}>You haven't referred anyone yet.</p>
            )}
          </div>
          <p style={{ color: theme.colors.text }}>
            Referrals: {referrals.length} / 5
            {referrals.length >= 5 && " - Congratulations! You've earned a free license key!"}
          </p>
        </CardContent>
      </Card>
    </div>
  )
}

