'use client'

import { useEffect, useState } from 'react'
import { Copy, MoreVertical, Search } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Switch } from '@/components/ui/switch'
import { LicenseService } from '@/lib/services/license-service'

interface LicenseKey {
  id: string
  key: string
  status: 'active' | 'inactive'
  createdAt: string
  lastUsed: string
  duration: string
}

export default function KeysPage() {
  const [keys, setKeys] = useState<LicenseKey[]>([])
  const [searchQuery, setSearchQuery] = useState('')

  useEffect(() => {
    setKeys(LicenseService.getAllLicenses())
  }, [])

  const handleCopyKey = (key: string) => {
    navigator.clipboard.writeText(key)
  }

  const handleToggleStatus = (id: string, currentStatus: 'active' | 'inactive') => {
    const newStatus = currentStatus === 'active' ? 'inactive' : 'active'
    LicenseService.updateLicenseStatus(id, newStatus)
    setKeys(LicenseService.getAllLicenses())
  }

  const handleDeleteKey = (id: string) => {
    if (confirm('Are you sure you want to delete this license key?')) {
      LicenseService.deleteLicense(id)
      setKeys(LicenseService.getAllLicenses())
    }
  }

  const filteredKeys = keys.filter((key) =>
    key.key.toLowerCase().includes(searchQuery.toLowerCase())
  )

  return (
    <div className="container mx-auto p-6">
      <Card>
        <CardHeader>
          <CardTitle>License Keys Management</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="mb-4">
            <div className="relative">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-500" />
              <Input
                placeholder="Search license keys..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-8"
              />
            </div>
          </div>
          <div className="space-y-4">
            {filteredKeys.map((key) => (
              <Card key={key.id}>
                <CardContent className="flex items-center justify-between p-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <code className="text-sm bg-gray-100 px-2 py-1 rounded">
                        {key.key}
                      </code>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleCopyKey(key.key)}
                      >
                        <Copy className="h-4 w-4" />
                      </Button>
                    </div>
                    <p className="text-sm text-gray-500">
                      Created: {new Date(key.createdAt).toLocaleDateString()} • 
                      Duration: {key.duration === 'lifetime' ? 'Lifetime' : `${key.duration} Month${Number(key.duration) > 1 ? 's' : ''}`}
                    </p>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2">
                      <Switch
                        checked={key.status === 'active'}
                        onCheckedChange={() => handleToggleStatus(key.id, key.status)}
                      />
                      <span className="text-sm font-medium">
                        {key.status === 'active' ? 'Active' : 'Inactive'}
                      </span>
                    </div>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <MoreVertical className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem
                          className="text-red-600"
                          onClick={() => handleDeleteKey(key.id)}
                        >
                          Delete Key
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

