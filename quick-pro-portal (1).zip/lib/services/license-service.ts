interface LicenseKey {
  id: string
  key: string
  status: 'active' | 'inactive'
  createdAt: string
  lastUsed: string
  duration: string
  username: string
}

export const LicenseService = {
  generateKey: () => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
    let result = 'D-1-'
    for (let i = 0; i < 8; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length))
    }
    return result
  },

  createLicense: (duration: string, username: string) => {
    const newKey: LicenseKey = {
      id: Math.random().toString(36).substr(2, 9),
      key: LicenseService.generateKey(),
      status: 'active',
      createdAt: new Date().toISOString(),
      lastUsed: new Date().toISOString(),
      duration,
      username
    }

    // Get existing keys
    const existingKeys = JSON.parse(localStorage.getItem('licenseKeys') || '[]')
    
    // Add new key
    const updatedKeys = [...existingKeys, newKey]
    
    // Save to localStorage
    localStorage.setItem('licenseKeys', JSON.stringify(updatedKeys))

    return newKey
  },

  getAllLicenses: () => {
    return JSON.parse(localStorage.getItem('licenseKeys') || '[]')
  },

  getLicensesByUsername: (username: string) => {
    const allLicenses = LicenseService.getAllLicenses()
    return allLicenses.filter((license: LicenseKey) => license.username === username)
  },

  updateLicenseStatus: (id: string, status: 'active' | 'inactive') => {
    const keys = LicenseService.getAllLicenses()
    const updatedKeys = keys.map((key: LicenseKey) =>
      key.id === id ? { ...key, status } : key
    )
    localStorage.setItem('licenseKeys', JSON.stringify(updatedKeys))
  },

  deleteLicense: (id: string) => {
    const keys = LicenseService.getAllLicenses()
    const updatedKeys = keys.filter((key: LicenseKey) => key.id !== id)
    localStorage.setItem('licenseKeys', JSON.stringify(updatedKeys))
  }
}

